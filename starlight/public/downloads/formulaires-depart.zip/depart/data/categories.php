<?php

/** Catégories admises. Sert aussi de liste blanche pour la validation. */
return [
    "sirop"      => "Sirops",
    "tartinade"  => "Tartinades",
    "confiserie" => "Confiseries",
    "coffret"    => "Coffrets",
];
