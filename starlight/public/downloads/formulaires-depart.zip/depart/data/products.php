<?php

/**
 * Catalogue de L'Érablière dorée.
 * Ce fichier ne produit aucune sortie : il retourne un tableau.
 */
return [
    ["id" => 1,  "nom" => "Sirop d'érable doré 540 ml",       "categorie" => "sirop",      "prix" => 14.50, "stock" => 12],
    ["id" => 2,  "nom" => "Sirop d'érable ambré 540 ml",      "categorie" => "sirop",      "prix" => 15.25, "stock" => 7],
    ["id" => 3,  "nom" => "Sirop d'érable foncé 1 L",         "categorie" => "sirop",      "prix" => 24.00, "stock" => 0],
    ["id" => 4,  "nom" => "Sirop d'érable très foncé 250 ml", "categorie" => "sirop",      "prix" => 9.75,  "stock" => 21],
    ["id" => 5,  "nom" => "Beurre d'érable 250 g",            "categorie" => "tartinade",  "prix" => 9.95,  "stock" => 0],
    ["id" => 6,  "nom" => "Beurre d'érable 500 g",            "categorie" => "tartinade",  "prix" => 17.50, "stock" => 4],
    ["id" => 7,  "nom" => "Gelée d'érable 190 ml",            "categorie" => "tartinade",  "prix" => 11.00, "stock" => 9],
    ["id" => 8,  "nom" => "Tire sur la neige (barquette)",    "categorie" => "confiserie", "prix" => 6.25,  "stock" => 30],
    ["id" => 9,  "nom" => "Sucre d'érable en grains 200 g",   "categorie" => "confiserie", "prix" => 8.40,  "stock" => 15],
    ["id" => 10, "nom" => "Bonbons à l'érable (sachet)",      "categorie" => "confiserie", "prix" => 5.50,  "stock" => 0],
    ["id" => 11, "nom" => "Coffret découverte 4 produits",    "categorie" => "coffret",    "prix" => 39.00, "stock" => 5],
    ["id" => 12, "nom" => "Coffret cabane à sucre",           "categorie" => "coffret",    "prix" => 62.00, "stock" => 2],
];
