</main>

<footer class="pied">
  <p>&copy; <?php echo date("Y"); ?> L'Érablière dorée &ndash; pages d'exercice</p>
</footer>

</body>
</html>
