<?php
// $titre peut être défini par la page avant l'inclusion.
$titre = $titre ?? "L'Érablière dorée";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo htmlspecialchars($titre); ?> &ndash; L'Érablière dorée</title>
  <link rel="stylesheet" href="/assets/style.css">
</head>
<body>

<header class="entete">
  <p class="marque">L'Érablière dorée</p>
  <nav>
    <a href="/ex02-catalogue/catalogue.php">Catalogue</a>
    <a href="/ex04-paiement/panier.php">Panier</a>
    <a href="/ex05-rendez-vous/rendez-vous.php">Rendez-vous</a>
    <a href="/ex06-inscription/inscription.php">Inscription</a>
  </nav>
</header>

<main>
