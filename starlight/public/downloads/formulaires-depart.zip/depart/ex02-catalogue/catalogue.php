<?php

/**
 * Exercice 2 — Filtrer le catalogue avec un formulaire GET.
 *
 * En l'état, la page affiche les douze produits, sans aucun filtre.
 */

$produits   = require __DIR__ . "/../data/products.php";
$categories = require __DIR__ . "/../data/categories.php";
$titre      = "Catalogue";

// TODO 1 — Lire les filtres dans $_GET 

// TODO 2 — Valider chaque filtre avant de s'en servir

// TODO 3 — Réduire $affiches selon les filtres retenus.
$affiches = $produits;

include __DIR__ . "/../includes/header.php";
?>

<h2>Catalogue</h2>

<!-- TODO 4 — Formulaire de filtres, utilisant GET, pointant vers cette même page.
              /!\ Les champs doivent réafficher les valeurs actives après envoi. -->

<p class="compte"><?php echo count($affiches); ?> produit(s)</p>

<div class="grille">
  <?php foreach ($affiches as $p): ?>
    <?php include __DIR__ . "/../partials/product-card.php"; ?>
  <?php endforeach; ?>
</div>

<?php include __DIR__ . "/../includes/footer.php"; ?>
