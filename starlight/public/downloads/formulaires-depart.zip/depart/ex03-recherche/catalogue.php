<?php

/**
 * Exercice 3 — Ajouter une barre de recherche au catalogue filtré.
 *
 * Les filtres de l'exercice 2 sont déjà en place.
 */

$produits   = require __DIR__ . "/../data/products.php";
$categories = require __DIR__ . "/../data/categories.php";
$titre      = "Catalogue";

// Lecture des filtres 
// ----------------------------------------------------------------------------
$categorie = $_GET["categorie"] ?? "";
$prixMax   = trim($_GET["prix_max"] ?? "");
$enStock   = isset($_GET["en_stock"]);

// Validation : une valeur inattendue est ramenée à « pas de filtre »
// ----------------------------------------------------------------------------
if (!array_key_exists($categorie, $categories)) {
    $categorie = "";
}
$plafond = $prixMax === "" ? false : filter_var($prixMax, FILTER_VALIDATE_FLOAT);
if ($plafond !== false && $plafond < 0) {
    $plafond = false;
}

// Application des filtres
// ----------------------------------------------------------------------------
$affiches = $produits;

if ($categorie !== "") {
    $affiches = array_filter($affiches, fn($p) => $p["categorie"] === $categorie);
}
if ($plafond !== false) {
    $affiches = array_filter($affiches, fn($p) => $p["prix"] <= $plafond);
}
if ($enStock) {
    $affiches = array_filter($affiches, fn($p) => $p["stock"] > 0);
}

// TODO 1 — Lire le terme de recherche, puis le normaliser.

// TODO 2 — Ne garder que les produits dont le nom contient ce terme,
//          sans tenir compte de la casse ni des espaces de bordure.

// TODO 3 — Si aucun produit ne correspond, prévoir un message plutôt
//          qu'une grille vide.

include __DIR__ . "/../includes/header.php";
?>

<h2>Catalogue</h2>

<!-- TODO 4 — Ajouter le champ de recherche à ce formulaire.
              /!\ Lancer une recherche ne doit pas effacer les filtres actifs. -->

<form class="filtres" method="get" action="">
  <label class="champ">
    <span>Catégorie</span>
    <select name="categorie">
      <option value="">Toutes</option>
      <?php foreach ($categories as $cle => $libelle): ?>
        <option value="<?php echo htmlspecialchars($cle); ?>"
          <?php echo $cle === $categorie ? "selected" : ""; ?>>
          <?php echo htmlspecialchars($libelle); ?>
        </option>
      <?php endforeach; ?>
    </select>
  </label>

  <label class="champ">
    <span>Prix maximal</span>
    <input type="number" name="prix_max" min="0" step="0.25"
           value="<?php echo htmlspecialchars($prixMax); ?>">
  </label>

  <label class="champ">
    <span>Disponibilité</span>
    <span>
      <input type="checkbox" name="en_stock" value="1" <?php echo $enStock ? "checked" : ""; ?>>
      En stock seulement
    </span>
  </label>

  <button type="submit">Filtrer</button>
  <a href="catalogue.php">Réinitialiser</a>
</form>

<p class="compte"><?php echo count($affiches); ?> produit(s)</p>

<div class="grille">
  <?php foreach ($affiches as $p): ?>
    <?php include __DIR__ . "/../partials/product-card.php"; ?>
  <?php endforeach; ?>
</div>

<?php include __DIR__ . "/../includes/footer.php"; ?>
