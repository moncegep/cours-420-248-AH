<?php
// Fragment inclus dans une boucle : il utilise $p, la variable du foreach.
?>
<article class="carte">
  <h3><?php echo htmlspecialchars($p["nom"]); ?></h3>
  <p class="categorie"><?php echo htmlspecialchars($p["categorie"]); ?></p>
  <p class="prix"><?php echo number_format($p["prix"], 2, ",", " "); ?> $</p>
  <p class="dispo <?php echo $p["stock"] > 0 ? "ok" : "rupture"; ?>">
    <?php echo $p["stock"] > 0 ? "En stock" : "Rupture"; ?>
  </p>
</article>
